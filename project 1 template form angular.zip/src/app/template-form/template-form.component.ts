import { Component, OnInit } from '@angular/core';
import { createSolutionBuilderWithWatch } from 'typescript';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit {
  first_name;
  last_name;
  email;
  pass;
  date;
  collectValue(formValue)
  {
    console.log(formValue.value);
    this.first_name=formValue.value.fname;
    this.last_name=formValue.value.lname;
    this.email=formValue.value.email;
    this.pass=formValue.value.pass;
    this.date=formValue.value.date;
    console.log();
    

    }

  

  constructor() { }

  ngOnInit(): void {
  }
}


